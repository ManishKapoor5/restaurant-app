import bg from '../assets/bg.png';
import chef from '../assets/chef.png';
import G from '../assets/G.png';
import gallery01 from '../assets/gallery01.png';
import gallery02 from '../assets/gallery02.png';
import gallery03 from '../assets1/gallery03.png';
import gallery04 from '../assets1/gallery04.png';
import knife from '../assets1/knife.png';
import logo from '../assets1/logo.png';
import menu from '../assets1/menu.png';
import overlaybg from '../assets/overlaybg.png';
import spoon from '../assets1/spoon.svg';
import welcome from '../assets/welcome.png';
// eslint-disable-next-line no-unused-vars
import Main from '../assets/Main.png';
import findus from '../assets/findus.png';
import laurels from '../assets1/laurels.png';
import award01 from '../assets/award01.png';
import award02 from '../assets/award02.png';
import award03 from '../assets/award03.png';
import award05 from '../assets/award05.png';
import sign from '../assets1/sign.png';
import quote from '../assets1/quote.png';
import gericht from '../assets1/gericht.png';

export default {
  bg,
  chef,
  G,
  gallery01,
  gallery02,
  gallery03,
  gallery04,
  knife,
  logo,
  menu,
  overlaybg,
  spoon,
  welcome,
  Main,
  findus,
  laurels,
  award01,
  award02,
  award03,
  award05,
  sign,
  quote,
  gericht,
};
